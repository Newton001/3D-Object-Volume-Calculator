#ifndef VTKWINDOW_H
#define VTKWINDOW_H

#include <QObject>
#include <vtkSmartPointer.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkVolume.h>
#include <vtkVolumeMapper.h>

class VTKWindow : public QObject {
    Q_OBJECT
public:
    explicit VTKWindow(QObject *parent = nullptr);
    ~VTKWindow();

    Q_INVOKABLE void showWindow();
    Q_INVOKABLE void loadFile(const QString &filePath); // Load a single file
    Q_INVOKABLE void loadFile2(const QString &filePath);
    Q_INVOKABLE void updateSettings(double lowerThreshold, double upperThreshold, int kernelSize, double smoothingStdDev);

private:
    QString filePath;

    double lowerThreshold = 50.0;
    double upperThreshold = 800.0;
    int kernelSize = 5;
    double smoothingStdDev = 1.0;

    vtkSmartPointer<vtkRenderer> renderer;
    vtkSmartPointer<vtkRenderWindow> renderWindow;
    vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor;
    vtkSmartPointer<vtkVolume> volume;

    void processImage();
};

#endif // VTKWINDOW_H
